package com.dxflay.mousepro

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.*
import android.graphics.drawable.GradientDrawable

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private val channelId = "dxflay_overlay"

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotification()
        showBubble()
    }

    private fun createNotification() {
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel(
                channelId, "DXFLAY Floating Menu", NotificationManager.IMPORTANCE_LOW
            ))
        }
        val notification = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, channelId)
        else Notification.Builder(this)
        startForeground(7, notification
            .setContentTitle("DXFLAY MOUSE PRO aktif")
            .setContentText("Floating menu berjalan. Ketuk gelembung untuk membuka panel.")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .build())
    }

    private fun overlayParams(width: Int, height: Int): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        return WindowManager.LayoutParams(
            width, height, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 30; y = 180 }
    }

    private fun bg(color: Int, radius: Float): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun showBubble() {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return }
        val b = TextView(this).apply {
            text = "DX"
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = bg(Color.rgb(0, 110, 230), 100f)
            elevation = 12f
            setOnClickListener { togglePanel() }
        }
        bubble = b
        val p = overlayParams(58, 58)
        p.flags = p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        b.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
            var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=p.x; sy=p.y; tx=e.rawX; ty=e.rawY; moved=false; return true }
                    MotionEvent.ACTION_MOVE -> {
                        val dx=(e.rawX-tx).toInt(); val dy=(e.rawY-ty).toInt()
                        if (kotlin.math.abs(dx)+kotlin.math.abs(dy)>8) moved=true
                        p.x=sx+dx; p.y=sy+dy
                        wm.updateViewLayout(b,p); return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) togglePanel()
                        return true
                    }
                }
                return false
            }
        })
        wm.addView(b, p)
    }

    private fun togglePanel() {
        if (panel == null) showPanel() else {
            try { wm.removeView(panel) } catch (_: Exception) {}
            panel = null
        }
    }

    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 16)
            background = bg(Color.rgb(9, 18, 36), 24f)
            elevation = 18f
        }
        val header = TextView(this).apply {
            text = "DXFLAY MOUSE PRO   •   ✕"
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(65, 175, 255))
            setPadding(0, 0, 0, 12)
            setOnClickListener { togglePanel() }
        }
        box.addView(header)
        addSwitch(box, "Floating panel aktif", true)
        addSlider(box, "Sensitivitas umum", 0, 100, 70)
        addSlider(box, "Ukuran tombol", 20, 100, 50)
        addSwitch(box, "Efek neon", true)
        val note = TextView(this).apply {
            text = "Pengaturan hanya untuk panel ini; tidak mengubah file atau kontrol internal game."
            textSize = 11f
            setTextColor(Color.LTGRAY)
            setPadding(0, 10, 0, 0)
        }
        box.addView(note)
        val p = overlayParams(290, WindowManager.LayoutParams.WRAP_CONTENT).apply {
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
            x = 75; y = 190
        }
        panel = box
        wm.addView(box, p)
    }

    private fun addSwitch(parent: LinearLayout, label: String, checked: Boolean) {
        val s = Switch(this).apply {
            text = label; isChecked = checked
            setTextColor(Color.WHITE)
            buttonTintList = android.content.res.ColorStateList.valueOf(Color.rgb(40,160,255))
        }
        parent.addView(s)
    }

    private fun addSlider(parent: LinearLayout, label: String, min: Int, max: Int, value: Int) {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 7, 0, 7) }
        val t = TextView(this).apply { text = "$label: $value"; setTextColor(Color.WHITE); textSize = 13f }
        val seek = SeekBar(this).apply { this.max = max-min; progress = value-min }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                t.text = "$label: ${progress+min}"
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        wrap.addView(t); wrap.addView(seek); parent.addView(wrap)
    }

    override fun onDestroy() {
        try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        bubble = null; panel = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
