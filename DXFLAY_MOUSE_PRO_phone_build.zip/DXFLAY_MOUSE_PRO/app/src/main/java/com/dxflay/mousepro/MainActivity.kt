package com.dxflay.mousepro

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 12, 25)
        window.navigationBarColor = Color.rgb(7, 12, 25)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(Color.rgb(7, 12, 25))
        }
        val title = TextView(this).apply {
            text = "DXFLAY MOUSE PRO"
            textSize = 25f
            setTextColor(Color.rgb(50, 170, 255))
            gravity = Gravity.CENTER
        }
        val desc = TextView(this).apply {
            text = "Floating gaming panel\nAktifkan izin overlay untuk menampilkan panel di atas game."
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 24)
        }
        val start = Button(this).apply {
            text = "AKTIFKAN FLOATING MENU"
            setOnClickListener { enableAndStart() }
        }
        val stop = Button(this).apply {
            text = "MATIKAN FLOATING MENU"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        }
        root.addView(title)
        root.addView(desc)
        root.addView(start)
        root.addView(stop)
        setContentView(root)
    }

    private fun enableAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
        startForegroundService(Intent(this, OverlayService::class.java))
    }

    override fun onResume() {
        super.onResume()
        // User can return here after granting overlay permission and tap Start.
    }
}
