# Build APK langsung dari HP (tanpa komputer)

1. Masuk ke https://github.com lewat browser HP dan login/buat akun.
2. Buat repository baru bernama `dxflay-mouse-pro` (Public atau Private).
3. Ekstrak ZIP proyek ini dengan ZArchiver.
4. Upload seluruh ISI folder proyek ke repository GitHub. Pastikan folder `.github/workflows` ikut ter-upload. Jika aplikasi file manager menyembunyikan `.github`, aktifkan tampilan file tersembunyi.
5. Buka tab **Actions** pada repository. Pilih workflow **Build DXFLAY MOUSE PRO APK**, lalu tekan **Run workflow**. Jika upload source memicu workflow otomatis, tunggu proses selesai.
6. Buka hasil workflow yang berstatus hijau, gulir ke **Artifacts**, lalu unduh `DXFLAY-MOUSE-PRO-APK`.
7. Ekstrak ZIP artifact dan instal `app-debug.apk`. Jika diminta, izinkan instalasi aplikasi dari sumber tersebut.

Build dilakukan di server GitHub, bukan di HP, sehingga RAM 8 GB cukup untuk mengelola file dan mengunduh hasilnya.

Catatan: APK debug untuk pengujian. Overlay perlu izin "Tampil di atas aplikasi lain". Slider sensitivitas hanya mengubah tampilan/pengaturan panel; tidak mengubah sensitivitas Free Fire atau mengirim input ke game.
