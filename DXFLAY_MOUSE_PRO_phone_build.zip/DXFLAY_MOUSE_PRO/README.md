# DXFLAY MOUSE PRO

Starter project Android 16 (API 36) untuk floating overlay panel yang dapat tampil di atas game/aplikasi.

## Kompatibilitas\n- Compile SDK 36 dan Target SDK 36 (Android 16).\n- Minimum Android 6.0 (API 23).\n\n## Build APK
1. Buka folder ini dengan Android Studio.
2. Tunggu Gradle Sync selesai.
3. Pilih Build > Build APK(s).
4. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Cara pakai
1. Instal APK.
2. Buka DXFLAY MOUSE PRO.
3. Tekan AKTIFKAN FLOATING MENU.
4. Izinkan "Display over other apps / Tampil di atas aplikasi lain".
5. Kembali ke aplikasi lalu tekan tombol aktifkan.
6. Gelembung DX dapat dipindah dan diketuk untuk membuka panel.

Catatan:
- Ini adalah proyek sumber, bukan APK yang sudah dikompilasi.
- Panel hanya menyediakan pengaturan visual lokal. Slider tidak mengubah sensitivitas Free Fire atau input game.
- Tidak ada auto-aim, modifikasi game, bypass anti-cheat, atau injeksi input.
- Android 13+ dapat meminta izin notifikasi untuk layanan foreground.
